/**
 * 64bitd - Script.js
 */

// ... (Resto das funções setupCharCounter, toggleEmailInput, closeModal permanecem as mesmas) ...

// 4. Função para carregar menu lateral (Sidebar) em todas as páginas internas
function loadSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return;

    // Estrutura do menu lateral injetada via JavaScript
    sidebar.innerHTML = `
        <div class="d-flex align-items-center mb-4">
            <img src="../img/logo.png" alt="Logotipo da 64bitd" class="logo me-2">
            <span class="fs-5 fw-bold text-light">64bitd</span>
        </div>
        <ul>
            <li><a href="index.html">Página inicial</a></li>
            <li><a href="explorar.html">Explorar</a></li>
            <li><a href="reviews.html">Meus reviews</a></li>
            <li><a href="mensagens.html">Mensagens</a></li>
            <li><a href="comunidades.html">Comunidades</a></li>
            <li><a href="perfil.html">Perfil</a></li>
            <li><a href="#">Mais</a></li>
        </ul>
        <div class="sidebar-footer">
            <img src="../img/profile-pic.jpg" alt="Foto de perfil de Edward Elric" class="rounded-circle">
            <span>Edward Elric d...</span>
        </div>
    `;
}

// ... (Resto do bloco document.addEventListener('DOMContentLoaded', function() { ... }) ...

// TODO: Certifique-se de copiar o código COMPLETO do js/script.js da penúltima resposta.